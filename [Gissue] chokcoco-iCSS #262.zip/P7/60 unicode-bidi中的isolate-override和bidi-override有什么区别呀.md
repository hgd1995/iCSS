做网盘项目 当前路径过长溢出省略  但是得三个点得在前面
就    ...xxx/xxxxxxxxxxxxxxxxxxxxxxx/xxx
最终用了路径的字符串reverse然后加这个css
```css
span{
    display: inline-block;
    max-width: 100%;
    direction: rtl;
    overflow: hidden;
    text-overflow: ellipsis;
    unicode-bidi: bidi-override;
    white-space: nowrap;
}
```
父元素固定了一个宽度  这样可以实现 效果 
唯一一点 他会挡住一点点 就最后的x会挡住一半
bidi-override的两个属性有啥区别 我用了用没啥区别
有没有什么更好的方法