正文从这里开始。

今天要介绍一种很简单的使用 CSS 控制动画播放与暂停的小技巧。使用好了，可以在很多实际场景得以运用。

我们先来看个例子，本例子是我在闲逛 Codepen 时看到了，很有意思：

![css-animation1 gif](https://user-images.githubusercontent.com/8554143/55217508-99c35c80-51f7-11e9-8a87-67ae1459b30a.gif)

[本例子 CodePen Demo -- CSS Beer!](https://codepen.io/mikegolus/pen/jJzRwJ)

上面整个过程都是由 CSS 完成。抛开如何用 CSS 实现上述一些 UI 效果。本文主要讲的是如何只用 CSS 控制一次动画的行进，暂停与开始。

## 拆解分析需求

上述动画控制要完成的效果是：

1. 页面 render 后，无任何操作，动画不会开始。只有当鼠标对元素进行 `click` ，触发元素的 `:active` 伪类效果的时候，动画才开始进行；
2. 动画进行到任意时刻，鼠标停止点击，则动画停止；
3. 重新对元素进行点击，动画继续从上一帧结束的状态开始
4. 如果动画播放完，再点击不会重复播放，动画状态保留在动画的最后一帧

## 解决需求

看着好像挺复杂的，其实实现起来很容易，主要借助了伪类 `:active` 与动画的播放状态 `animation-play-state` 。

我们以一个运动的小球做一个简单的示例，小球从左运动到右。

```HTML
<div></div>
```
```CSS
div {
    margin: 50px auto;
    width: 100px;
    height: 100px;
    background: #000;
    animation: move 1s linear;
    animation-fill-mode: forwards;
}

@keyframes move {
    100% {
        transform: translate(200px, 0) rotate(180deg);
    }
}
```

![](https://user-images.githubusercontent.com/8554143/55223622-84a1fa00-5206-11e9-8024-56125f9b1926.gif)

接下来，我们就进行简单的改造，动画的默认状态是暂停的：
```CSS
div {
    margin: 50px auto;
    width: 100px;
    height: 100px;
    background: #000;
    animation: move 1s linear;
    animation-fill-mode: forwards;
+   animation-play-state: paused;
}
```

只有通过点击的时候，动画才会运行：
```CSS
body:active div {
    animation-play-state: running;
}
```

看看效果，为了方便看清点击的过程，在点击的过程中，我也改了下背景颜色（背景变色表示当前鼠标按下）：
![css-animation3 gif](https://user-images.githubusercontent.com/8554143/55224548-abf9c680-5208-11e9-8e8f-18f043a14879.gif)

[CodePen Demo -- CSS控制动画行进](https://codepen.io/Chokcoco/pen/XGvwjL)

## 总结一下

嗯，整个过程其实非常简单。理解了这种方法后，就可以随意加到你想的任何动画中，再抛一个类似的 Demo：

![](https://user-images.githubusercontent.com/8554143/55224859-422dec80-5209-11e9-9297-eba3bb834246.gif)

[CodePen Demo -- CSS 控制动画行进](https://codepen.io/Chokcoco/pen/ZPgxwy)

非常有用的一个小技巧，赶紧 GET 起来。

## 最后

好了，本文到此结束，希望对你有帮助 :)

想 Get 到最有意思的 CSS 资讯，千万不要错过我的公众号 -- **iCSS前端趣闻** 😄

<img width=160 src="https://raw.githubusercontent.com/chokcoco/chokcoco/main/qrcode_big.png">

更多精彩 CSS 技术文章汇总在我的 [Github -- iCSS](https://github.com/chokcoco/iCSS) ，持续更新，欢迎点个 star 订阅收藏。

如果还有什么疑问或者建议，可以多多交流，原创文章，文笔有限，才疏学浅，文中若有不正之处，万望告知。