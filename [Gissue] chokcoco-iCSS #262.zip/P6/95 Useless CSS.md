想再开个专题，叫做 Useless CSS，专门写一些没用什么意义的 CSS 技巧。（但是有趣！）

譬如下面这些：
 
+ [利用鼠标滚轮实现水平滚动](https://codepen.io/Chokcoco/pen/abBbegE)
+ [使用 CSS 实现签名板](https://codepen.io/Chokcoco/pen/gOLbrYJ)

😆 