谈到 `<fieldset>` 与 `<legend>`，大部分人肯定会比较陌生，在 HTML 标签中，属于比较少用的那一批。

我最早知道这两个标签，是在早年学习 reset.css 或者 normalize.css 时，在这些重置统一代码默认样式的 CSS 中看到的。最近因为研究边框，遇到了这两个标签，发现它们还是很有意思的，遂起一篇，将整理的一些知识点分享给大家。

## 了解 `<fieldset>` 与 `<legend>`

通常而言，`<fieldset>` 与 `<legend>` 比较常用在表单当中。

+ `<fieldset>`：HTML `<fieldset>` 元素用于对表单中的控制元素进行分组
+ `<legend>`：在  `<fieldset>` 中内置了一个 `<legend>` 元素作为 fieldset 的标题

简单而言，**fieldset** 可以单独使用，对表单的元素进行分组，而 `legend` 则需要和 `fieldset` 配套使用，成对出现，**作为分组的标题**。

看个简单的例子，简单的 HTML 及结构如下：

```HTML
<fieldset>
    <legend>Form</legend>
    <div>
        <label>Name :</label><input type="text" placeholder="input Name" />
    </div>
    <div>
        <label>Password :</label><input type="text" placeholder="input Name" />
    </div>
</fieldset>
```

```CSS
fieldset {
    border: 1px solid#ddd;
    padding: 12px;
}

legend {
    font-size: 18px;
    padding: 0 10px;
}
```

效果如下：

![image](https://user-images.githubusercontent.com/8554143/105191293-dea94780-5b71-11eb-97a3-7788ec1df75f.png)

[CodePen Demo -- fieldset &  legend Demo ](https://codepen.io/Chokcoco/pen/poEYYBa)

比较有意思的点在于，如果给 `fieldset` 设置了 `border` 边框，则 `legend` 元素内的内容则会作为分组的标题，嵌入 `border` 内。

### 控制 `legend` 的位置及样式

对于 `legend` 的位置和样式，是可以进行控制的。

对于位置，我们可以通过 `margin` 和 父元素的 `padding` 进行控制，如果父元素 `fieldset ` 不设置 `padding` ，`legend` 不设置 margin ，则 `legend` 默认定位在最左侧。

```CSS
fieldset {
    border: 1px solid#ddd;
    // padding: 12px;
}

legend {
    font-size: 18px;
}
```

效果图：

![image](https://user-images.githubusercontent.com/8554143/105192548-2da3ac80-5b73-11eb-9571-0ba1a14d731d.png)

通过改变 `legend` 的 `margin` 或者父元素的 `padding-left` ，可以控制标题的初始位置：

```CSS
fieldset {
    border: 1px groove #ddd;
}

legend {
    animation: marginMove 10s infinite alternate;
}

@keyframes marginMove {
    100% {
        margin-left: 100px;
    }
}
```

效果图：

![legend1](https://user-images.githubusercontent.com/8554143/105193659-af93d580-5b73-11eb-8126-fda25f529a38.gif)

通过控制 `legend` 的 `padding`，可以增加周围元素的区域，让留白更多一点。

![image](https://user-images.githubusercontent.com/8554143/105194901-fcc47700-5b74-11eb-8ec7-3c38f094b910.png)

## 应用场景 -- 标题两侧横线

了解了上述基本知识后，我们就可以稍微开始深入，想一想，上述 `<fieldset>` 与 `<legend>` 的一些有意思的应用场景。

最适合的场景我觉得应该就是标题两侧带横线的布局了。类似这样：

![image](https://user-images.githubusercontent.com/8554143/105195454-9c820500-5b75-11eb-9a15-f0458b87824f.png)

当然，这个布局的解决方式有很多，通常会使用伪元素来生成左右两侧的横线，或者是通过绝对定位局部进行覆盖叠加。

这里，使用  `<fieldset>` 与 `<legend>` 非常快速的完成：

```HTML
<div class="g-container">
	<fieldset><legend>排行榜</legend></fieldset>
</div>
```

```CSS
fieldset {
	width: 300px; 
	height: 24px; 
	border: 1px solid transparent; 
	border-top-color: #000; 
}

legend{
	margin: auto; 
	padding: 0 10px; 
} 
```

`fieldset` 只设置上边框，通过 `margin: auto` 将标题定位到中间， 通过 `padding` 控制两侧的留白。非常的完美。

[CodePen Demo --  fieldset & legend Demo 2 ](https://codepen.io/Chokcoco/pen/xxEMWYe)

## 边框嵌套文字

在这篇文章中 -- [How to Add Text in Borders Using Basic HTML Elements](https://css-tricks.com/how-to-add-text-in-borders-using-basic-html-elements/)，还介绍了一种非常有意思的使用场景，**在边框中嵌套文字**。

想象一下，一个 `<fieldset>` 元素配合一个 `<legend>` 元素，可以生成一个边框嵌文字的效果，那么，将多组组合，再进行定位排布，就可以生成多边边框嵌套文字的效果了。

伪代码如下：

```HTML
<div class="g-container">
	<fieldset><legend>CSS fieldset</legend></fieldset>
	<fieldset><legend>HTML element</legend></fieldset>
	<fieldset><legend>JavaScript</legend></fieldset>
	<fieldset><legend>TypeScript</legend></fieldset>
</div>
```

```CSS
.g-container {
	position: relative;
	width: 300px; 
	height: 300px; 
}
fieldset{
	position: absolute;
	width: 300px; 
	height: 300px; 
	border: 10px solid transparent; 
	border-top-color: #000; 
}
legend{
    padding: 0 10px; 
} 

fieldset:nth-of-type(2){ transform: rotate(90deg); }
fieldset:nth-of-type(3){ transform: rotate(180deg); }
fieldset:nth-of-type(3)>legend{ transform: rotate(180deg); } 
fieldset:nth-of-type(4){ transform: rotate(-90deg); }
```
效果图如下：

![image](https://user-images.githubusercontent.com/8554143/105197984-2c28b300-5b78-11eb-96e2-26213af4cd90.png)

通过多个  `<fieldset>` 和 `<legend>` 的组合，我们可以拼出一个容器的 4 个边，组成一个非常好看的边框嵌文字效果。

通过给 `legend` 加上 `animation`，让文字动起来

```CSS
legend{
	animation: move 3s infinite linear alternate;
} 
@keyframes move {
	100% {
		margin-left: 70px;
	}
}
```

![legend2](https://user-images.githubusercontent.com/8554143/105198685-e02a3e00-5b78-11eb-9a3e-318c87c17bb2.gif)

[CodePen Demo -- Border Text Design using HTML fieldset and legend](https://codepen.io/Chokcoco/pen/xxEMxMx)

好，基于这个，我们就可以去生成各种 N 边形边框嵌文字的边框了。下面是简单的尝试 几种多边形边框。

![image](https://user-images.githubusercontent.com/8554143/105354113-11fbdd00-5c2b-11eb-9788-ff1902a900f4.png)

[CodePen Demo -- fieldset and legend generate polygon ](https://codepen.io/Chokcoco/pen/zYKbQpN)

## 需要注意的是

当然，需要注意的一点是，如果从语义化的角度来出发，使用 `<fieldset>` 与 `<legend>` 来制作边框效果是不太符合语义化的。

所以使用语义化标签来作为装饰呈现来用的话，可以给标签设置 `role=presentation`，这样可以屏蔽掉标签的语义性，如果不屏蔽，那些靠屏幕阅读器阅读的用户就会觉得很困惑。

## 最后

本文到此结束，希望对你有帮助 :)，想 Get 到最有意思的 CSS 资讯，千万不要错过我的公众号 -- iCSS前端趣闻 😄

<img width=160 src="https://user-images.githubusercontent.com/8554143/54919342-6d0dfd00-4ef8-11e9-9ee8-fbae9241d89e.png">

更多精彩 CSS 技术文章汇总在我的 [Github -- iCSS](https://github.com/chokcoco/iCSS) ，持续更新，欢迎点个 star 订阅收藏。

如果还有什么疑问或者建议，可以多多交流，原创文章，文笔有限，才疏学浅，文中若有不正之处，万望告知。