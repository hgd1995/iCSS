本文内容源自：[A Sorted List of CSS Code Examples: Master Styling HTML Elements](https://www.bitdegree.org/learn/css-code)

非完全直译，按照我的理解有所改动。

如果你是一名初学者，并且希望系统性的掌握 CSS，那么这里有一整套可供你理解并且模仿学习的 DEMO(HTML+CSS)，并且是所见即所得。

## CSS 知识点拆分

这里，首先我们会将整个 CSS 知识点分拆，分为：

[1. Color](https://www.bitdegree.org/learn/css-code#color)
[2. Backgrounds](https://www.bitdegree.org/learn/css-code#backgrounds)
[3. Borders](https://www.bitdegree.org/learn/css-code#borders)
[4. Margins](https://www.bitdegree.org/learn/css-code#margins)
[5. Padding](https://www.bitdegree.org/learn/css-code#padding)
[6. Height and Width](https://www.bitdegree.org/learn/css-code#height-and-width)
[7. Box Model](https://www.bitdegree.org/learn/css-code#box-model)
[8. Outline](https://www.bitdegree.org/learn/css-code#outline)
[9. Text](https://www.bitdegree.org/learn/css-code#text)
[10. Fonts](https://www.bitdegree.org/learn/css-code#fonts)
[11. Links](https://www.bitdegree.org/learn/css-code#links)
[12. Lists](https://www.bitdegree.org/learn/css-code#lists)
[13. Tables](https://www.bitdegree.org/learn/css-code#tables)
[14. Display](https://www.bitdegree.org/learn/css-code#display)
[15. Position](https://www.bitdegree.org/learn/css-code#position)
[16. Overflow](https://www.bitdegree.org/learn/css-code#overflow)
[17. Float](https://www.bitdegree.org/learn/css-code#float)
[18. Inline-Block](https://www.bitdegree.org/learn/css-code#inline-block)
[19. Align Elements](https://www.bitdegree.org/learn/css-code#align-elements)
[20. Combinators](https://www.bitdegree.org/learn/css-code#combinators)
[21. Pseudo-Class](https://www.bitdegree.org/learn/css-code#pseudo-class)
[22. Pseudo-Elements](https://www.bitdegree.org/learn/css-code#pseudo-elements)
[23. Opacity](https://www.bitdegree.org/learn/css-code#opacity)
[24. Navigation Bars](https://www.bitdegree.org/learn/css-code#navigation-bars)
[25. Dropdowns](https://www.bitdegree.org/learn/css-code#dropdowns)
[26. Images](https://www.bitdegree.org/learn/css-code#images)
[27. Attribute Selectors](https://www.bitdegree.org/learn/css-code#attribute-selectors)
[28. Forms](https://www.bitdegree.org/learn/css-code#forms)
[29. Counters](https://www.bitdegree.org/learn/css-code#counters)
[30. Website Layout](https://www.bitdegree.org/learn/css-code#website-layout)
[31. Transform](https://www.bitdegree.org/learn/css-code#transform)
[32. Transition](https://www.bitdegree.org/learn/css-code#transition)
[33. Animations](https://www.bitdegree.org/learn/css-code#animations)
[34. Tooltips](https://www.bitdegree.org/learn/css-code#tooltips)
[35. Buttons](https://www.bitdegree.org/learn/css-code#buttons)
[36. Pagination](https://www.bitdegree.org/learn/css-code#pagination)
[37. Multiple Columns](https://www.bitdegree.org/learn/css-code#multiple-columns)
[38. Grid](https://www.bitdegree.org/learn/css-code#grid)
[39. Flexbox](https://www.bitdegree.org/learn/css-code#flexbox)
[40. Media Queries](https://www.bitdegree.org/learn/css-code#media-queries)
[41. Responsive](https://www.bitdegree.org/learn/css-code#responsive)

基于每一个知识点，都提供了完善且充分的 DEMO 可以对照练习。其中的 DEMO 基本涵盖了该属性的所有知识点！

跟着这些 DEMO：

1. 对于刚入门 CSS 的，对照着完整过一篇，可以巩固基础
2. 而对于对 CSS 有一定掌握的，也可以对照选择性练习，查缺补漏
3. 亦可以当做一本字典

## Color

All CSS styles include the [color](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-7) property. You can pick color codes from our useful [Pickeristic](https://www.bitdegree.org/learn/color-scale) tool.

+ [​Assign background-color to an element using color names](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-1)
+ [Assign background-color to an element using RGB indicators](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-2)
+ [Assign background-color to an element using RGBA indicators](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-4)
+ [​Assign background-color to an element using HEX indicators](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-3)
+ [​Assign background-color to an element using HSL indicators](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-5)
+ [​Assign background-color to an element using HSLA indicators](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-6)
+ [​Specify how opaque or how transparent a color is](https://www.bitdegree.org/learn/best-code-editor/css-colors-example-7)

## Backgrounds

The following list of CSS code examples illustrates different actions you can perform on page [backgrounds](https://www.bitdegree.org/learn/css-background-color). Learn to set colors or images as backgrounds and control the way they look on web sites.

+ [Set background color](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-1)
+ [Use background image](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-2)
+ [Repeat background image](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-3)
+ [Specify background image position](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-4)
+ [Use background attachment property](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-5)
+ [Background shorthand example](https://www.bitdegree.org/learn/best-code-editor/css-backgrounds-example-6)
+ [Set multiple background images](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-1)
+ [Use shorthand to set multiple background images](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-2)
+ [Resize background image](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-3)
+ [Contain and cover background size](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-4)
+ [Set size for multiple background images](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-5)
+ [Full size background image](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-6)
+ [Specify background origin](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-7)
+ [Use background clip](https://www.bitdegree.org/learn/best-code-editor/css3-backgrounds-example-8)
+ [Apply the linear gradient for your background without specifying direction](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-1)
+ [Apply the linear gradient for your background from left to right](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-2)
+ [Diagonal linear gradient from top left to bottom right](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-3)
+ [Linear gradient with a defined angle](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-4)
+ [Create the linear gradient background with multiple colors (default direction)](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-5)
+ [Create the linear gradient background with multiple colors from left to right](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-6)
+ [Linear gradient (left-right) with changing transparency](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-7)
+ [Create repeating linear gradient](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-8)
+ [Apply the radial gradient with evenly spaced color stops](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-9)
+ [Apply the radial gradient with differently spaced color stops](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-10)
+ [Set a circle shaped radial gradient](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-11)
+ [Manipulate radial gradient size parameters](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-12)
+ [Use a repeating radial gradient](https://www.bitdegree.org/learn/best-code-editor/css3-gradients-example-13)


## Borders

These CSS code examples manipulate [borders](https://www.bitdegree.org/learn/css-border) of HTML elements.

+ [Set unique CSS border style to each element](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-8)
+ [Apply different CSS border style to individual walls](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-1)
+ [Specify CSS border width](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-2)
+ [Define CSS border color using different color value indicators](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-3)
+ [Use border-radius to create rounded borders](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-4)
+ [Assign individual styles to each wall of a CSS border](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-5)
+ [Use shorthand to define border-width, border-color, and border-style](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-6)
+ [Apply style to a single CSS border wall using the shorthand property](https://www.bitdegree.org/learn/best-code-editor/css-borders-example-7)
+ [Use an image as a CSS border by stretching it](https://www.bitdegree.org/learn/best-code-editor/css3-border-images-example-1)
+ [Use an image as a CSS border by repeating it](https://www.bitdegree.org/learn/best-code-editor/css3-border-images-example-2)
+ [Use different slice values to create different borders from the same image](https://www.bitdegree.org/learn/best-code-editor/css3-border-images-example-3)

## Margins

Practice setting the [margin](https://www.bitdegree.org/learn/margin-css) property for HTML elements in these CSS examples:

+ [Determine four different CSS margin values](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-6)
+ [Determine three CSS margin values](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-7)
+ [Determine only two CSS margin values](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-8)
+ [Define just one value for all margins to be equal](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-9)
+ [Specify all individual CSS margin values separately](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-1)
+ [Use auto value for CSS margin](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-3)
+ [Set CSS margin to inherit its value](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-4)
+ [Collapse vertical margins](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-5)

## Padding

The CSS code examples below show the options for setting [padding](https://www.bitdegree.org/learn/css-padding). You can use the shorthand or declare values in separate declarations:

+ [Determine all four CSS padding values in one declaration](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-example-1)
+ [Specify CSS padding-top value individually](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-padding-top-example)
+ [Specify CSS padding-right value individually](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-padding-right-example)
+ [Specify CSS padding-left value individually](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-padding-left-example)
+ [Specify CSS padding-bottom value individually](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-padding-bottom-example)
+ [Use box-sizing: border-box to avoid width and padding conflict](https://www.bitdegree.org/learn/best-code-editor/css-padding-property-padding-and-width-conflict-example)

## Height and Width

Learn to set unique [height and width](https://www.bitdegree.org/learn/css-height) properties for HTML elements.

+ [Set height and width of an element using px](https://www.bitdegree.org/learn/best-code-editor/css-height-and-width-dimensions-example-1)
+ [Set height and width of an element using %](https://www.bitdegree.org/learn/best-code-editor/css-height-and-width-dimensions-example-3)
+ [Specify a max-width value of an element](https://www.bitdegree.org/learn/best-code-editor/css-height-and-width-dimensions-example-2)
+ [Center an element using width and margin: auto](https://www.bitdegree.org/learn/best-code-editor/css-margins-example-3-0j)
+ [Understand difference between width and max-width](https://www.bitdegree.org/learn/best-code-editor/css-layout-width-and-max-width-example-1)

## Box Model

CSS [box model](https://www.bitdegree.org/learn/css-box-model) indicates that browsers see HTML elements as rectangular boxes.

+ [Set all CSS properties that make up CSS box model](https://www.bitdegree.org/learn/best-code-editor/css-box-model-example-1)
+ [Compare elements with and without padding](https://www.bitdegree.org/learn/best-code-editor/css3-box-sizing-example-1)
+ [Add box-sizing: border-box to manage dimensions of certain elements](https://www.bitdegree.org/learn/best-code-editor/css3-box-sizing-example-2)
+ [Apply box-sizing: border-box to all elements at once](https://www.bitdegree.org/learn/best-code-editor/css3-box-sizing-example-3)
+ [Create an element with resizable width](https://www.bitdegree.org/learn/best-code-editor/css3-user-interface-example-1)
+ [Create an element with resizable height](https://www.bitdegree.org/learn/best-code-editor/css3-user-interface-example-2)
+ [Create an element with resizable width and height](https://www.bitdegree.org/learn/best-code-editor/css3-user-interface-example-3)
+ [Disable resizing on elements that are resizable by default](https://www.bitdegree.org/learn/best-code-editor/css3-user-interface-example-5)

## Outline

The following CSS code examples show the ways to control the [outline](https://www.bitdegree.org/learn/css-outline) property.

+ [Set different outline-style values](https://www.bitdegree.org/learn/best-code-editor/css-outline-example-1)
+ [Specify outline color using a color keyword value](https://www.bitdegree.org/learn/best-code-editor/css-outline-example-2)
+ [Specify outline width using a size in px or a predefined keyword value](https://www.bitdegree.org/learn/best-code-editor/css-outline-example-3)
+ [Set outline offset property to create space between border and outline](https://www.bitdegree.org/learn/best-code-editor/css-outline-example-offset)
+ [Use outline shorthand for outline-width, outline-style, and outline-color](https://www.bitdegree.org/learn/best-code-editor/css-outline-example-4)

## Text

CSS styles the [text](https://www.bitdegree.org/learn/css-text) content with the following options:

+ [Specify the color of your text using color keyword name and HEX indicator](https://www.bitdegree.org/learn/best-code-editor/css-text-example-1)
+ [Align text left, center, right or justified](https://www.bitdegree.org/learn/best-code-editor/css-text-example-2)
+ [Try all types of text decoration](https://www.bitdegree.org/learn/best-code-editor/css-text-example-3)
+ [Use text-transform to set all uppercase, lowercase or capitalized characters](https://www.bitdegree.org/learn/best-code-editor/css-text-example-4)
+ [Specify the indentation of your text](https://www.bitdegree.org/learn/best-code-editor/css-text-example-5)
+ [Use custom letter spacing to make your words more spacious out or compact](https://www.bitdegree.org/learn/best-code-editor/css-text-example-6)
+ [Use word spacing to make your text more spacious or compact](https://www.bitdegree.org/learn/best-code-editor/css-text-example-9)
+ [Adjust line height to create more space between lines](https://www.bitdegree.org/learn/best-code-editor/css-text-example-7)
+ [Set text direction right to left](https://www.bitdegree.org/learn/best-code-editor/css-text-example-8)
+ [Define shadow radius and color for your text](https://www.bitdegree.org/learn/best-code-editor/css-text-example-10)
+ [Specify how text overflow (text that doesn’t fit) is displayed](https://www.bitdegree.org/learn/best-code-editor/css3-text-example-1)
+ [Display full overflow text when hovered on](https://www.bitdegree.org/learn/best-code-editor/css3-text-example-2)
+ [Make long text wrap when it doesn’t fit in a line](https://www.bitdegree.org/learn/best-code-editor/css3-text-example-3)
+ [Use word-break to break-all or keep-all words](https://www.bitdegree.org/learn/best-code-editor/css3-text-example-4)
+ [Add multiple shadows to your text separated by commas](https://www.bitdegree.org/learn/best-code-editor/css3-shadow-effects-example-1)


## Fonts
CSS code examples below show how to use [fonts](https://www.bitdegree.org/learn/css-font), specify font families, apply bold or italic effects, and so much more.

+ [Specify font family for your text](https://www.bitdegree.org/learn/best-code-editor/css-fonts-example-1)
+ [Specify font style for your text](https://www.bitdegree.org/learn/best-code-editor/css-fonts-example-2)
+ [Define font size using predefined keywords, percentage or length indicators](https://www.bitdegree.org/learn/best-code-editor/css-fonts-example-3)
+ [Specify font weight to create bold effect](https://www.bitdegree.org/learn/best-code-editor/css-fonts-example-4)
+ [Use font variant to make characters appear as small caps](https://www.bitdegree.org/learn/best-code-editor/css-fonts-example-5)
+ [Use @font-face rule to apply non-CSS font family fonts](https://www.bitdegree.org/learn/best-code-editor/css3-web-fonts-example-1)
+ [Use font-weight with @font-face rule](https://www.bitdegree.org/learn/best-code-editor/css3-web-fonts-example-2)

## Links

You can also style [links](https://www.bitdegree.org/learn/css-link-color) by setting colors, controlling states, etc.

+ [Set a color for your link](https://www.bitdegree.org/learn/best-code-editor/css-links-example-1)
+ [Set different colors for different states of links](https://www.bitdegree.org/learn/best-code-editor/css-links-example-3)
+ [Specify custom link background colors for different states](https://www.bitdegree.org/learn/best-code-editor/css-links-example-4)
+ [Make your link a CSS button](https://www.bitdegree.org/learn/best-code-editor/css-links-example-5)

## Lists

Control the way [lists](https://www.bitdegree.org/learn/css-list-style) are presented on your web pages by following the CSS code examples below.

+ [Specify item markers for lists](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-1)
+ [Use images for item markers of lists](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-2)
+ [Define item marker position outside the list](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-3)
+ [Use list-style shorthand to set type, position and image](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-4)
+ [Set various color and layout styles to your lists](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-5)
+ [Create lists with background and borders](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-6)
+ [Create a bordered list without item markers](https://www.bitdegree.org/learn/best-code-editor/css-lists-example-7)

## Tables

The following CSS code examples help you change the default settings of [tables](https://www.bitdegree.org/learn/css-table).

+ [Specify border width, color and style for a table](https://www.bitdegree.org/learn/best-code-editor/css-table-example-1)
+ [Collapse table borders](https://www.bitdegree.org/learn/best-code-editor/css-table-example-2)
+ [Use border spacing on uncollapsed borders](https://www.bitdegree.org/learn/best-code-editor/css-table-example-3)
+ [Create a caption text for the table](https://www.bitdegree.org/learn/best-code-editor/css-table-example-4)
+ [Add empty cells in a table](https://www.bitdegree.org/learn/best-code-editor/css-table-example-5)
+ [Define auto, fixed or initial table layout](https://www.bitdegree.org/learn/best-code-editor/css-table-example-6)
+ [Set specific table width and height](https://www.bitdegree.org/learn/best-code-editor/css-table-width-height-example)
+ [Specify text alignment in a table](https://www.bitdegree.org/learn/best-code-editor/css-table-text-align-example-1)
+ [Specify vertical content alignment in a table](https://www.bitdegree.org/learn/best-code-editor/css-table-vertical-align-example)
+ [Set padding for your table content](https://www.bitdegree.org/learn/best-code-editor/css-table-padding-example)
+ [Set only horizontal borders for a table](https://www.bitdegree.org/learn/best-code-editor/css-table-horizontal-borders-example)
+ [Create table cells with a hover effect](https://www.bitdegree.org/learn/best-code-editor/css-table-mouse-over-example)
+ [Specify table colors](https://www.bitdegree.org/learn/best-code-editor/css-table-colors-example)
+ [Create a zebra-striped table design](https://www.bitdegree.org/learn/best-code-editor/css-table-zebra-striped-design-example)

## Display

Practice hiding HTML elements and otherwise manipulating them with [display](https://www.bitdegree.org/learn/css-display) with these CSS code examples:

+ [Override the default display value to inline](https://www.bitdegree.org/learn/best-code-editor/css-layout-the-display-property-example-1)
+ [Override the default display value to block](https://www.bitdegree.org/learn/best-code-editor/css-layout-the-display-property-example-2)
+ [Hide an element using display: none](https://www.bitdegree.org/learn/best-code-editor/css-layout-the-display-property-example-3)
+ [Hide an element using visibility: hidden](https://www.bitdegree.org/learn/best-code-editor/css-layout-the-display-property-example-4)

## Position

The following CSS code examples control the [position](https://www.bitdegree.org/learn/css-position) of HTML elements.

+ [Set static position for an element](https://www.bitdegree.org/learn/best-code-editor/css-position-property-example-1)
+ [Set relative position for an element](https://www.bitdegree.org/learn/best-code-editor/css-position-property-example-2)
+ [Set fixed position for an element](https://www.bitdegree.org/learn/best-code-editor/css-position-property-example-3)
+ [Set absolute position for an element](https://www.bitdegree.org/learn/best-code-editor/css-position-property-example-4)

## Overflow

Learn to deal with [text overflowing](https://www.bitdegree.org/learn/css-text) its content box.

+ [Set overflow text to ellipsis](https://www.bitdegree.org/learn/best-code-editor/css3-text-overflow-property-example-1)
+ [Show overflown text when hovered on](https://www.bitdegree.org/learn/best-code-editor/css3-text-overflow-property-example-2)
+ [Set overflow-y to hidden](https://www.bitdegree.org/learn/best-code-editor/css3-overflow-y-property-example-1)
+ [Set overflow-x to hidden](https://www.bitdegree.org/learn/best-code-editor/css3-overflow-x-property-example-1)

## Float

The CSS code examples below [float](https://www.bitdegree.org/learn/css-float) elements to specified sides.

+ [Float an element to the left](https://www.bitdegree.org/learn/best-code-editor/css-float-example-1)
+ [Float an element to the right](https://www.bitdegree.org/learn/best-code-editor/css-float-example-12)
+ [Use float: none to keep an element in its original place](https://www.bitdegree.org/learn/best-code-editor/css-float-example-13)
+ [Use clear to determine where elements shouldn’t float](https://www.bitdegree.org/learn/best-code-editor/css-float-example-2)
+ [Use overflow: auto to fix issues with overflow](https://www.bitdegree.org/learn/best-code-editor/css-layout-horizontal-align-example-4)

## Inline-Block

These CSS code examples show the use of [inline-block](https://www.bitdegree.org/learn/css-display).

+ [Setting CSS display: inline block and setting width and height](https://www.bitdegree.org/learn/best-code-editor/css-display-example-5)
+ [Another basic use of CSS display: inline-block](https://www.bitdegree.org/learn/best-code-editor/css-layout-inline-block-example-2)

## Align Elements

CSS styles elements by indicating their [alignment](https://www.bitdegree.org/learn/css-align).

+ [Center vertically with position and transform](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-10)
+ [Center vertically with line-height](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-9)
+ [Center vertically and horizontally using padding](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-8)
+ [Center vertically with padding](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-7)
+ [Fix image overflow with clearfix](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-6)
+ [Align an element to the left with float](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-5)
+ [Align an element to the left with position](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-4)
+ [Center an image my using auto margin on a block element](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-3)
+ [Center text using text-align](https://www.bitdegree.org/learn/best-code-editor/css-layout-align-2)
+ [Center an element inside a container with margin](https://www.bitdegree.org/learn/best-code-editor/css-layout-align)

## Combinators

By using [combinators](https://www.bitdegree.org/learn/css-child-selector), you can select specific HTML elements to style according to their relations to other elements.

+ [Select only direct child elements](https://www.bitdegree.org/learn/best-code-editor/css-combinators-example-2)
+ [Select all descending elements](https://www.bitdegree.org/learn/best-code-editor/css-combinators-example-1)
+ [Select all the sibling elements](https://www.bitdegree.org/learn/best-code-editor/css-combinators-example-4)
+ [Select only adjacent sibling elements](https://www.bitdegree.org/learn/best-code-editor/css-combinators-example-3)


## Pseudo-Class

Practice using [pseudo classes](https://www.bitdegree.org/learn/css-pseudo-classes) for styling elements in certain states.

+ [Set different link states using pseudo classes](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-2)
+ [Change element color upon CSS hover with pseudo classes](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-3)
+ [Change background color upon CSS hover with pseudo classes](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-4)
+ [Match pseudo class to the first child element](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-5)
+ [Match pseudo class to every first child element](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-6)
+ [Match pseudo class to all specified elements in all first child elements](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-7)
+ [Define special rules for different languages using pseudo class :lang](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-classes-example-8)

## Pseudo-Elements

The following CSS codes show how [pseudo-elements](https://www.bitdegree.org/learn/css-pseudo-elements) style specific parts of elements.

+ [Set style for the first line](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-2)
+ [Set style for the first letter](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-3)
+ [Insert specific content before an element](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-6)
+ [Insert specific content after an element](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-7)
+ [Style a specified portion of an element](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-8)
+ [Combine multiple pseudo elements in one document](https://www.bitdegree.org/learn/best-code-editor/css-pseudo-elements-example-5)

## Opacity

Set [opacity](https://www.bitdegree.org/learn/css-opacity) for HTML elements and make them transparent.

+ [Specify opacity to make an image transparent](https://www.bitdegree.org/learn/best-code-editor/css-image-opacity-transparency-property-example-1)
+ [Apply opacity settings upon hover](https://www.bitdegree.org/learn/best-code-editor/css-image-opacity-transparency-property-example-2)
+ [Create transparent box](https://www.bitdegree.org/learn/best-code-editor/css-image-opacity-transparent-box-example)
+ [Specify transparency with RGBA](https://www.bitdegree.org/learn/best-code-editor/css-image-opacity-transparency-using-rgba-example)
+ [Manipulate text in a transparency box](https://www.bitdegree.org/learn/best-code-editor/css-image-opacity-transparency-property-example-3)

## Navigation Bars

The following CSS code examples show how to create and style [navigation bars](https://www.bitdegree.org/learn/css-navigation-bar).

+ [Build a navigation bar from HTML links](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-1)
+ [Remove default browser settings from your navigation bar](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-2)
+ [Specify text and background colors for hover effect](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-4)
+ [Create basic vertical navigation bar](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-5)
+ [Specify the style for your active navigation links](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-13)
+ [Add borders and alignment to your navigation list](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-7)
+ [Create a fixed vertical navbar](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-8)
+ [Create a horizontal navigation bar](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-9)
+ [Create a horizontal navigation bar using float](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-10)
+ [Create a horizontal navbar with a changing color upon hover](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-12)
+ [Add a class to inform users about selected navigation item](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-5)
+ [Align navigation links to the right](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-14)
+ [Create a navbar with individual dividers](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-15)
+ [Create a fixed top horizontal navbar using position](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-fixed-top-example-16)
+ [Create a fixed bottom horizontal navbar using position](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-fixed-bottom-example-17)
+ [Create a fully functioning navigation bar](https://www.bitdegree.org/learn/best-code-editor/css-navigation-bar-example-18)

## Dropdowns

By following the CSS codes below, you can create [dropdown menus](https://www.bitdegree.org/learn/css-dropdown-menu) for your websites.

+ [Create a basic dropdown menu](https://www.bitdegree.org/learn/best-code-editor/css-dropdowns-example-1)
+ [Create a dropdown menu with links](https://www.bitdegree.org/learn/best-code-editor/css-dropdowns-example-2)
+ [Align your dropdown menu to the right](https://www.bitdegree.org/learn/best-code-editor/css-dropdowns-example-3)

## Images

CSS styles [images as galleries](https://www.bitdegree.org/learn/css-image-gallery), lets you create [image sprites](https://www.bitdegree.org/learn/css-images) and manipulate such content in other ways.

+ [Create an image gallery using CSS styling properties](https://www.bitdegree.org/learn/best-code-editor/css-image-gallery-example-1)
+ [Define a part of image to display](https://www.bitdegree.org/learn/best-code-editor/css-image-sprites-example-1)
+ [Make a navigation bar using image sprite](https://www.bitdegree.org/learn/best-code-editor/css-image-sprites-example-2)
+ [Use image sprites with hover effect](https://www.bitdegree.org/learn/best-code-editor/css-image-sprites-example-3)
+ [Set image width to 100%](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images)
+ [Set image max-width to 100%](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-2)
+ [Keep aspect ratio: contain background-size](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-images-example-4)
+ [Specify background-size to stretch and fill](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-images-example-5)
+ [Set background image to cover the area & keep aspect ratio](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-images-example-6)
+ [Display different images depending on screen size](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-4)
+ [Use @media rule to make images responsive](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-5)
+ [Use HTML5 <picture> element](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-6)

## Attribute Selectors

These CSS code examples teach you how to select and style elements according to their [attributes](https://www.bitdegree.org/learn/css-attribute-selector).

+ [Select all elements with specified attribute](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-1)
+ [Select elements with specified attribute & value](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-2)
+ [Select elements with specified value regardless of its placement](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-3)
+ [Select elements that start with a specified value](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-4)
+ [Select elements that start with a specified value describing just part of it](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-5)
+ [Select elements that end with a specified value](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-6)
+ [Select elements with a specified value anywhere in the attribute](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-7)
+ [Apply styling properties using CSS selector](https://www.bitdegree.org/learn/best-code-editor/css-attribute-selectors-example-8)

## Forms

CSS styles [forms](https://www.bitdegree.org/learn/css-form) by indicating how input fields, submit buttons and text areas look.

+ [Select all input elements](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-1)
+ [Use padding to create space around input field](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-2)
+ [Add and style a border for a CSS form](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-3)
+ [Add only a bottom border for a CSS form](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-4)
+ [Specify a background color for your input field](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-5)
+ [Specify a background color for a focused input](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-6)
+ [Specify a border style for a focused input](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-7)
+ [Add an icon to your input field](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-8)
+ [Create an animated stretching input field](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-9)
+ [Style a text area](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-10)
+ [Style a dropdown menu](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-11)
+ [Style input buttons](https://www.bitdegree.org/learn/best-code-editor/css-forms-example-12)

## Counters

The following code examples show the use of [counters](https://www.bitdegree.org/learn/css-variables).

+ [Create a simple list with CSS counters](https://www.bitdegree.org/learn/best-code-editor/css-counters-example-1)
+ [Make a table of contents using CSS counters](https://www.bitdegree.org/learn/best-code-editor/css-counters-example-2)
+ [Create an outlined list with CSS counters](https://www.bitdegree.org/learn/best-code-editor/css-counters-example-3)

## Website Layout

Control [website layout](https://www.bitdegree.org/learn/css-columns) by following the examples below.

+ [Build a responsive website layout using CSS columns](https://www.bitdegree.org/learn/best-code-editor/css-grid-view-7)
+ [Create a flexible website layout using flex properties](https://www.bitdegree.org/learn/best-code-editor/css-flexbox-layout-2)

## Transform

Learn to use the [transform](https://www.bitdegree.org/learn/transform-css) property to rotate elements and create simple animations.

+ [Rotate an element around its horizontal axis](https://www.bitdegree.org/learn/best-code-editor/css3-3d-transforms-example-1)
+ [Rotate an element around its vertical axis](https://www.bitdegree.org/learn/best-code-editor/css3-3d-transforms-example-2)
+ [Rotate an element around its depth axis](https://www.bitdegree.org/learn/best-code-editor/css3-3d-transforms-example-3)

## Transition

The CSS code examples below reveal the use of [transitions](https://www.bitdegree.org/learn/css-transition) to create animation effects on elements.

+ [Create a width transition effect upon hover](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-2)
+ [Create a transition with width and height properties](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-3)
+ [Specify different speed curves for your transition](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-4)
+ [Create a transition with delay effect](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-5)
+ [Create a transition with transform and set its duration](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-6)
+ [Specify individual transition properties in separate declarations](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-7)
+ [Specify all transition properties in a single declaration](https://www.bitdegree.org/learn/best-code-editor/css3-transitions-example-8)

## Animations

CSS can create [animations](https://www.bitdegree.org/learn/css-animation) for HTML elements by making them fade out, fade in, etc.

+ [Assign animation rule to an element](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-1)
+ [Set changes using percentages for a smoother animation effect](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-2)
+ [Change animation position using percentage](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-3)
+ [Create fade in animation](https://www.bitdegree.org/learn/best-code-editor/css-animations-1)
+ [Specify animation delay](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-4)
+ [Set animation to repeat](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-5)
+ [Set an infinite animation](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-6)
+ [Run animation in reverse](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-7)
+ [Run animation forwards then backwards](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-8)
+ [Run animation backwards then forwards](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-12)
+ [Specify an animation speed curve](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-9)
+ [Set animation fill mode forwards](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-13)
+ [Set animation fill mode backwards](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-14)
+ [Set animation fill mode forwards and backwards](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-15)
+ [Use six major animation properties](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-10)
+ [Use animation shorthand property](https://www.bitdegree.org/learn/best-code-editor/css3-animations-example-11)


## Tooltips

The following CSS codes illustrate the creation, styling, and positioning of [tooltips](https://www.bitdegree.org/learn/css-tooltip).

+ [Create a basic tooltip](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-example-1)
+ [Create a tooltip on the right](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-right-tooltip-2)
+ [Create a tooltip on the left](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-left-tooltip-3)
+ [Create a tooltip above an element](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-top-tooltip-4)
+ [Create a tooltip below an element](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-bottom-tooltip-5)
+ [Create a tooltip with a bottom arrow](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-bottom-arrow-6)
+ [Create a tooltip with a top arrow](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-top-arrow-7)
+ [Create a tooltip with a left arrow](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-left-arrow-8)
+ [Create a tooltip with a right arrow](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-right-arrow-9)
+ [Create a tooltip with a fade in effect](https://www.bitdegree.org/learn/best-code-editor/css-tooltip-example-10)

## Buttons

Learn to create and style [buttons](https://www.bitdegree.org/learn/css-button) with different properties.

+ [Assign colors to buttons](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-2)
+ [Define text size for buttons](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-3)
+ [Specify padding for buttons](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-15-AV)
+ [Make your button corners rounded](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-4)
+ [Add different color borders to your buttons](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-5)
+ [Create a button with hover effect](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-6)
+ [Create buttons with a shadow](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-7)
+ [Make a button appear inactive](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-8)
+ [Define width of the button](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-9)
+ [Align several buttons together using float](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-10)
+ [Add borders to grouped buttons](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-11)
+ [Create a vertical button group](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-15)
+ [Add a button on an image using position](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-16)
+ [Create a button with an arrow animation](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-12)
+ [Create a pressed button effect](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-13)
+ [Create a fade in button](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-17)
+ [Create a button with a ripple effect](https://www.bitdegree.org/learn/best-code-editor/css-buttons-example-14)

## Pagination

Learn to organize many links with these CSS [pagination](https://www.bitdegree.org/learn/pagination-examples) examples.

+ [Create a simple pagination style](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-1)
+ [Assign hover and active effects on your pagination list](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-2)
+ [Apply border-radius to create rounded corners](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-3)
+ [Create a transition effect on hover](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-4)
+ [Create a pagination list with borders](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-5)
+ [Add space around page links](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-7)
+ [Specify pagination text size](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-8)
+ [Center your pagination list](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-9)
+ [Create breadcrumbs from an unordered HTML list](https://www.bitdegree.org/learn/best-code-editor/css-pagination-examples-example-11)

## Multiple Columns

These CSS code examples show how content can be divided into [columns](https://www.bitdegree.org/learn/css-columns) and styled with additional properties.

+ [Divide elements to separate columns](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-1)
+ [Specify the width of a column](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-2)
+ [Specify the width between columns](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-3)
+ [Set the style of column borders](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-4)
+ [Specify the weight of column borders](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-5)
+ [Specify the color of column borders](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-6)
+ [Use shorthand for column border style, weight and color](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-7)
+ [Span across multiple columns](https://www.bitdegree.org/learn/best-code-editor/css3-multiple-columns-example-8)

## Grid

These code examples show how to manipulate [grid](https://www.bitdegree.org/learn/columns-css) (the layout of a web page).

+ [Build a responsive grid with CSS columns](https://www.bitdegree.org/learn/best-code-editor/css-grid-view-7)
+ [Build a responsive grid with two CSS columns](https://www.bitdegree.org/learn/best-code-editor/css-grid-view-2)
+ [Build and style CSS columns](https://www.bitdegree.org/learn/best-code-editor/css-grid-view-7)
+ [Set the box-sizing property to create CSS columns](https://www.bitdegree.org/learn/best-code-editor/css-grid-view)

## Flexbox

Analyze these CSS code examples to learn how to create responsive websites by using [flexbox](https://www.bitdegree.org/learn/css-flexbox).

+ [Create flexible boxes](https://www.bitdegree.org/learn/best-code-editor/css-flexbox-layout)
+ [Make image grid responsive using flexbox](https://www.bitdegree.org/learn/best-code-editor/css-flexbox-layout-2)
+ [Create a responsive website layout with flexbox](https://www.bitdegree.org/learn/best-code-editor/css-flexbox-layout-3)
+ [Set flex-direction: column](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-1)
+ [Set flex-direction: column-reverse](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-2)
+ [Set flex-direction: row](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-3)
+ [Set flex-direction: row-reverse](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-4)
+ [Define flex-wrap: wrap](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-5)
+ [Define flex-wrap: nowrap](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-6)
+ [Define flex-wrap: wrap-reverse](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-7)
+ [Use flex-flow shorthand for flex-direction and flex-wrap](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-8)
+ [Align flex items in a container with justify-content: center](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-11)
+ [Align flex items in a container with justify-content: flex-start](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-9)
+ [Align flex items in a container with justify-content: flex-end](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-10)
+ [Align flex items in a container with justify-content: space-around](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-13)
+ [Align flex items in a container with justify-content: space-between](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-12)
+ [Center flex items vertically using align-items: center](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-16)
+ [Align flex items at the top of a container with align-items: flex-start](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-14)
+ [Align flex items at the bottom of a container with align-items: flex-end](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-15)
+ [Stretch the container’s space to contain flex items using align-items: stretch](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-17)
+ [Use align-items: baseline](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-18)
+ [Set justify-content and align-items to center flex item perfectly](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-19)
+ [Align flex lines using align-content: space-between](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-24)
+ [Align flex lines using align-content: space-around](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-25)
+ [Align flex lines using the default option align-content: stretch](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-23)
+ [Align flex lines in the middle of a container using align-content: center](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-22)
+ [Align flex lines in the beginning of a container with align-content: flex-start](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-20)
+ [Align flex lines in the end of a container with align-content: flex-end](https://www.bitdegree.org/learn/best-code-editor/flex-container-example-21)
+ [Create flexible items inside a container](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-1)
+ [Specify in what order flex items should be displayed](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-2)
+ [Specify how much a flex item should grow in relation to other flex items](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-3)
+ [Specify how much a flex item should shrink in relation to other flex items](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-4)
+ [Determine the initial length of a flex item](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-5)
+ [Use flex shorthand for flex-grow, flex-shrink, and flex-basis properties](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-6)
+ [Align an item inside a flexible container using align-self: center](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-7)
+ [Align individual flexible items with align-self: flex-start and flex-end](https://www.bitdegree.org/learn/best-code-editor/flex-item-example-8)

## Media Queries

Learn to make your website mobile-friendly by including [@media and breakpoints](https://www.bitdegree.org/learn/responsive-media).

+ [Change background color based on screen width](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-1-1)
+ [Create a responsive navigation menu](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-2-2)
+ [Align elements based on screen width](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-3-3)
+ [Create a responsive layout with flex properties](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-4-4)
+ [Hide unnecessary elements for small screen devices](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-media-queries-example-7)
+ [Adjust font size based on screen size](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-media-queries-example-8)
+ [Use media queries to create a flexible image gallery](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-5-5)
+ [Create a flexible website using media queries](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-6-6)
+ [Change layout orientation when a screen rotates](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-media-queries-example-6)
+ [Assign several min- and max- properties to a single @media rule](https://www.bitdegree.org/learn/best-code-editor/css3-media-queries-examples-example-7-7)

## Responsive

These CSS code examples reveal additional options for creating responsive web pages.

+ [Set viewport meta tag](https://www.bitdegree.org/learn/best-code-editor/viewport-1)
+ [Keep the aspect ratio of an image when scaling](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-2)
+ [Set image to cover area but keep aspect ratio](https://www.bitdegree.org/learn/best-code-editor/responsive-web-design-images-example-4)
+ [Use different images based on device used](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-4)
+ [Set min-device-width to respond to device viewport width](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-5)
+ [Define HTML5 <picture>](https://www.bitdegree.org/learn/best-code-editor/responsive-css-background-images-6)
+ [Set a video player to scale up and down](https://www.bitdegree.org/learn/best-code-editor/css-videos-2)
+ [Add a responsive video](https://www.bitdegree.org/learn/best-code-editor/css-videos-3)