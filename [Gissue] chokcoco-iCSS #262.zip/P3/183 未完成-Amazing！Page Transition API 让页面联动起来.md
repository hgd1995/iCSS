本文未完成

-----

[Smooth and simple page transitions with the shared element transition API](https://developer.chrome.com/blog/shared-element-transitions-for-spas/)
[Bringing page transitions to the web](https://www.youtube.com/watch?v=JCJUPJ_zDQ4)