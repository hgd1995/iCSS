本文未完成

通过本文，你可以学习到：

1. 单行省略，省略内容在最后
2. 单行省略，省略内容在最前面
3. 单行省略，省略内容在中间
4. 多行省略，省略内容在最后
5. 多行省略，省略内容在最前面
6. 多行省略，省略内容在中间

-----

+ [CodePen Demo -- CSS Ellipsis Beginning of String](https://codepen.io/Chokcoco/pen/BaWBELx)
+ [cuttr-js](https://github.com/d-e-v-s-k/cuttr-js)